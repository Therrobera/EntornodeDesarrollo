# Proyecto de Prueba: Entorno de Desarrollo

Este proyecto contiene un pequeño programa en C que imprime un mensaje. Ideal para pruebas de entorno en máquinas virtuales educativas.

## Compilación

```bash
make
```

## Ejecución

```bash
./ejemplo-ejecutable
```